#pragma once
#include "DatalogParser.h"
#include "Database.h"
#include "Relation.h"
#include <fstream>
using namespace std;

class Interpreter {
private:
	vector<Predicate> schemesList;
	vector<Predicate> factsList;
	vector<Rule> rulesList;
	vector<Predicate> queriesList;
	ofstream output;
	Database database;
public:
	Interpreter(DatalogParser, string);
	void evaluateSchemes();
	void evaluateFacts();
	void evaluateRules();
	void evaluateQueries();
    void interpRename(bool, vector<string>&, vector<int>&, Relation&);
    void interpProject(bool, vector<string>&, vector<int>&, Relation&);
    void interpPrint(bool&, vector<string>&, Relation&, int);
	void interpJoin(vector<pair<string, int>>&, Relation&, vector<string>&, vector<Parameter>&, vector<string>&);
	void relationJoin(Tuple&, Tuple&, Relation&, vector<int>&);
	vector<Parameter> combineSchemes(vector<Parameter>&, vector<Parameter>&, vector<pair<string, int>>&, vector<string>&, string, string);
	void setNewSchemes(vector<Parameter>&, vector<int>&, Relation&);
	Relation unionFacts(Relation&);
	Relation findNewFacts(Relation&, string);
	string createName(vector<string>);
	void makeVarNames(Relation&, vector<string>&);
	void onePredicateJoin(int, vector<Predicate>&, int);
	void evaluatePredicateJoins(int, int, vector<pair<string, int>>&, Relation&, vector<Parameter>&);
	void removeTempRelations();
	void matchlessJoin(map<string, Relation>&, vector<string>&, Relation&);
	void joinable(vector<pair<string, int>>&, Tuple&, Tuple&, Relation&);
	vector<int> findLiterals(vector<string>&, map<string, Relation>&, vector<pair<string, int>>&);
	void iterateTuples(vector<pair<string,int>>&, vector<int>&, vector<string>&, Relation&);
    void iterateTuples2(int i, map<string,Relation>&, vector<pair<string, int>>&, vector<int>&, vector<string>&,Relation&);
};
