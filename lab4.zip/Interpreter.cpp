#include "Interpreter.h"
#include "Parameter.h"
using namespace std;

Interpreter::Interpreter(DatalogParser parser, string fileName) {
	Database database;
	output.open(fileName);
	schemesList = parser.getSchemesList();
	factsList = parser.getFactsList();
	rulesList = parser.getRulesList();
	queriesList = parser.getQueriesList();
}

void Interpreter::evaluateSchemes() {
	output << "Scheme Evaluation" << endl << endl;
    for (unsigned int i = 0; i < schemesList.size(); ++i) {
		Relation newRelation;
		string name = schemesList[i].getID();
		newRelation.setName(name);
        for (unsigned int j = 0; j < schemesList[i].getParams().size(); j++) {
			Parameter p = schemesList[i].getParams()[j];
			string value = p.getValue();
			newRelation.setScheme(value);
		}
		database.initializeRelations(pair<string, Relation>(name, newRelation));
	}
}

void Interpreter::evaluateFacts() {
	output << "Fact Evaluation" << endl << endl;
	set<string> factNames;
    for (unsigned int i = 0; i < schemesList.size(); ++i) {
        string factName = schemesList[i].getID();
        factNames.insert(factName);
    }
    for (unsigned int i = 0; i < factsList.size(); ++i) {
		Tuple tuple;
		string factName = factsList[i].getID();
		factNames.insert(factName);
        for (unsigned int j = 0; j < factsList[i].getParams().size(); ++j) {
			Parameter p = factsList[i].getParams()[j];
			string value = p.getValue();
			tuple.push_back(value);
		}
		database.setTuple(factName, tuple);
	}
	for (auto names : factNames) {
        output << database.getRelations()[names].toString(true) << endl;
	}
}

void Interpreter::evaluateQueries() {
    output << "Query Evaluation" << endl << endl;
	for (unsigned int i = 0; i < queriesList.size(); i++) {
		output << queriesList[i].toString() << "?";
		string name = queriesList[i].getID();
		Relation r = database.getRelations()[name];
		bool found = false;
		vector<int> varPos;
		vector<string> varName;
		map<string, int> variables;
		//select for loops
        for (unsigned int j = 0; j < queriesList[i].getParams().size(); ++j) {
			Parameter p1 = queriesList[i].getParams()[j];
			if (variables.count(p1.getValue()) == 0 && p1.getisID()) {
				variables[p1.getValue()] = j;
				varPos.push_back(j);
				varName.push_back(p1.getValue());
			}
			else if (!p1.getisID()) {
				found = r.selectValue(j, p1.getValue());
			}
			else {
				found = r.selectVariables(variables[p1.getValue()], j);
			}
		}
        interpPrint(found, varName, r, i);
        //project for loops
        interpProject(found, varName, varPos, r);
        //rename
        interpRename(found,varName,varPos,r);
    }
    output.close();
}

void Interpreter::evaluateRules() {
	output << "Rule Evaluation" << endl << endl;
	int ruleSize = rulesList.size();
    int tupleCount = -1;
	int converge = 0;
	while (tupleCount != database.getTupleCount()) {
		converge++;
		tupleCount = database.getTupleCount();
		for (int i = 0; i < ruleSize; ++i) {
			Predicate pred1 = rulesList[i].getPred();
			vector<Parameter> params3 = pred1.getParams();
			vector<Predicate> preds = rulesList[i].getPreds();
			output << rulesList[i].toString() << endl;
			int predSize = preds.size();
			onePredicateJoin(predSize,preds,i);
			vector<pair<string, int>> matches;
			vector<string> varNames;
			Relation newRelation;
			vector<int> varPos;
			int schemeSize = 0;
			evaluatePredicateJoins(i,schemeSize, matches,newRelation,params3);
			setNewSchemes(params3, varPos,newRelation);
			newRelation.project(varPos);
			makeVarNames(newRelation, varNames);
			newRelation.rename(varPos, varNames);
			Relation tempR = findNewFacts(newRelation, newRelation.getName());
			Scheme newScheme = newRelation.getScheme();
            for (unsigned int j = 0; j < newScheme.size(); ++j) {
				tempR.setScheme(newScheme[j]);
			}
			tempR.setName(newRelation.getName());
			unionFacts(newRelation);
			if (tupleCount != database.getTupleCount()) {
				output << tempR.toString(false);
			}
			if (predSize == 1) {
				rulesList[i].popPred();
			}			
		}
	}
	removeTempRelations();
	output << endl << "Converged after " << to_string(converge) << " passes through the Rules." << endl << endl;
	output << database.toString();
}

void Interpreter::interpPrint(bool &found, vector<string>& varName, Relation& r, int i) {


    if (queriesList[i].getParams().size() == r.getScheme().size() && factsList.size() > 0) {
        found = true;
        r.setMatches(r.getTuples().size());
    }
    if (found && r.getMatches() > 0) {
        output << " Yes(" << to_string(r.getMatches()) << ")" << endl << "select" << endl << r.toString(false);
    }
    else {
        found = false;
        output << " No" << endl << endl;
    }
}

void Interpreter::interpProject(bool found, vector<string>& varName, vector<int>& varPos, Relation &r) {
    if (found && varName.size() > 0) {
        r.project(varPos);
        output << "project" << endl << r.toString(false);
    }
    else if(found)
        output << "project" << endl;
}

void Interpreter::interpRename(bool found, vector<string>& varName, vector<int>& varPos, Relation &r) {
    if (found && varName.size() > 0) {
        r.rename(varPos, varName);
        output << "rename" << endl << r.toString(false) << endl;
    }
    else if(found)
        output << "rename" << endl << endl;
}

vector<Parameter> Interpreter::combineSchemes(vector<Parameter>& p1, vector<Parameter>& p2, vector<pair<string,int>>& matches, vector<string>& schemes, string n1, string n2) {
	vector<Parameter> params;
	int paramSize1 = p1.size();
	int paramSize2 = p2.size();
	for (int i = 0; i < paramSize1; ++i) {
		string v1 = p1[i].getValue();
		schemes.push_back(v1);
		for (int j = 0; j < paramSize2; ++j) {
			string v2 = p2[j].getValue();
			if (v1 == v2) {
				pair<string, int> match1 = { n1, i };
				pair<string, int> match2 = { n2, j };
				matches.push_back(match1);
				matches.push_back(match2);
			}
			if (i == paramSize1 - 1) {
				schemes.push_back(v2);
			}
		}
	}
	map<string, int> schemeMap;
	int tempSize = 0;
	for (unsigned int i = 0; i < schemes.size(); ++i) {
		string scheme = schemes[i];
		Parameter p;
		pair <string, int> schemePos = { scheme, i };
		schemeMap.insert(schemePos);
		tempSize++;
		int mapSize = schemeMap.size();
		if (tempSize == mapSize) {
			p.setValue(scheme);
			p.setisID(true);
			params.push_back(p);
			continue;
		}
		else {
			schemes.erase(schemes.begin() + i);
			tempSize--;
			i--;
		}
	}
	return params;
}

void Interpreter::interpJoin(vector<pair<string,int>>& matches, Relation& newRelation, vector<string>& schemeNames, vector<Parameter>& parameter, vector<string>& schemes) {
	map<string, Relation> relations = database.getRelations();
	vector<int> literals = findLiterals(schemes, relations,  matches);
	newRelation.clearTuples();
	if(matches.size() == 0)
	matchlessJoin(relations, schemeNames, newRelation);
	iterateTuples(matches, literals, schemes, newRelation);
}

void Interpreter::relationJoin(Tuple& t1, Tuple& t2, Relation& newRelation,vector<int>& match) {
	int tupleSize1 = t1.size();
	int tupleSize2 = t2.size();
	Tuple newTuple;
	for (int i = 0; i < tupleSize1; ++i) {
		newTuple.push_back(t1[i]);
	}
	for (unsigned int j = 0; j < match.size(); ++j) {
		for (int i = 0; i < tupleSize2; ++i) {
		
			if (i != match[j]) {
				newTuple.push_back(t2[i]);
			}
		}
	}
	newRelation.setTuples(newTuple);
}

Relation Interpreter::unionFacts(Relation& newRelation) {
    map<string, Relation> relations = database.getRelations();
    set<Tuple> tuples = newRelation.getTuples();
	Relation tempR = relations.at(newRelation.getName());
	for (set<Tuple>::iterator it = tuples.begin(); it != tuples.end(); ++it) {
		tempR.setTuples(*it);
	}
	pair<string, Relation> pair = { newRelation.getName(), tempR };
	database.setRelations(pair);
	return tempR;
}

void Interpreter::setNewSchemes(vector<Parameter>& parameter, vector<int>& varPos, Relation& newRelation) {

	vector<string> projectVars;
	for (unsigned int i = 0; i < parameter.size(); ++i) {
		string param = parameter[i].getValue();
		projectVars.push_back(param);
	}
	Scheme schemes = newRelation.getScheme();
	int schemeSize = newRelation.getScheme().size();
	int varSize = projectVars.size();
	for (int i = 0; i < varSize; ++i) {
		for (int j = 0; j < schemeSize; ++j) {
			if (schemes[j] == projectVars[i]) {
				varPos.push_back(j);
			}
		}
	}
}

Relation Interpreter::findNewFacts(Relation& r1,string name) {
	Relation tempR;
	map<string, Relation> relations = database.getRelations();
	Relation rData = relations.at(name);
	set<Tuple> tData = rData.getTuples();
	set<Tuple> t1 = r1.getTuples();
	for (set<Tuple>::iterator it = tData.begin(); it != tData.end(); ++it) {
		Tuple t = *it;
		t1.erase(t);
	}
	for (set<Tuple>::iterator it = t1.begin(); it != t1.end(); ++it) {
		tempR.setTuples(*it);
	}
	return tempR;
}

string Interpreter::createName(vector<string> v) {
	string output;
	for (int i = 0; i < v.size(); ++i) {
		output += v[i];
	}
	return output;
}

void Interpreter::makeVarNames(Relation& newRelation, vector<string>& varNames) {
	for (unsigned int j = 0; j < schemesList.size(); ++j) {
		if (schemesList[j].getID() == newRelation.getName()) {
			vector<Parameter> p1 = schemesList[j].getParams();
			int paramSize = p1.size();
			for (int k = 0; k < paramSize; ++k) {
				string values = p1[k].getValue();
				varNames.push_back(values);
			}
		}
	}
}

void Interpreter::onePredicateJoin(int predSize, vector<Predicate>& preds, int i) {
	if (predSize == 1) {
		Predicate p;
		p.setID(preds[0].getID());
		for (int j = 0; j < predSize; ++j) {
			vector<Parameter> params = preds[j].getParams();
			for (int k = 0; k < params.size(); ++k) {
				Parameter p1 = params[k];
				p.setParams(p1);
			}
		}
		rulesList[i].addPredicates(p);
	}
}

void Interpreter::evaluatePredicateJoins(int i, int schemeSize, vector<pair<string,int>>& matches, Relation& newRelation,  vector<Parameter>&params3) {
	vector<string> schemes;
	vector<string> relationNames;
	vector<Parameter> params1;
	vector<Predicate> preds = rulesList[i].getPreds();
	string predName1;
	for (int j = 0; j < preds.size(); ++j) {
		if (j == 0) {
			params1 = preds[j].getParams();
			predName1 = preds[j].getID();
		}
		if (j + 1 < preds.size()) {
			vector<Parameter> params2 = preds[j + 1].getParams();
			string predName2 = preds[j + 1].getID();
			relationNames.push_back(predName1);
			relationNames.push_back(predName2);
			params1 = combineSchemes(params1, params2, matches, schemes, predName1, predName2);
			predName1 = createName(schemes);
			interpJoin(matches, newRelation, relationNames, params3,schemes);
			newRelation.setName(rulesList[i].getPred().getID());
			schemeSize = schemes.size();
			pair<string, Relation> tempRelation = { predName1,newRelation };
			database.setRelations(tempRelation);
		}
		relationNames.clear();
		matches.clear();
	}
	for (int k = 0; k < schemeSize; ++k) {
		newRelation.setScheme(schemes[k]);
	}
}

void Interpreter::removeTempRelations() {
	map<string, Relation> relations = database.getRelations();
	for (map<string, Relation>::iterator it = relations.begin(); it != relations.end(); ++it) {
		bool found = false;
		pair<string, Relation> p = *it;
		int fake = p.second.getScheme().size();
		if (fake == 0) {
			database.removeRelation(p.first);
		}
	}
}

void Interpreter::matchlessJoin(map<string,Relation>& relations, vector<string>& schemeNames, Relation& newRelation) {

		for (unsigned int i = 0; i < schemeNames.size(); ++i) {
			Relation r1 = relations.at(schemeNames[i]);
			if (i < schemeNames.size() - 1) {
				Relation r2 = relations.at(schemeNames[i + 1]);
				set<Tuple> tuples1 = r1.getTuples();
				set<Tuple> tuples2 = r2.getTuples();
				for (set<Tuple>::iterator it1 = tuples1.begin(); it1 != tuples1.end(); ++it1) {
					Tuple t1 = *it1;
					for (set<Tuple>::iterator it2 = tuples2.begin(); it2 != tuples2.end(); ++it2) {
						Tuple t2 = *it2;
						for (unsigned int j = 0; j < t2.size(); ++j) {
							t1.push_back(t2[j]);
						}
						newRelation.setTuples(t1);
						for (unsigned int j = 0; j < t2.size(); ++j) {
							t1.pop_back();
						}
					}
				}
			}
		}
}

void Interpreter::joinable(vector<pair<string, int>>& matches, Tuple& t1, Tuple& t2, Relation& newRelation) {
	bool join = true;
	vector<int> match;
	for (unsigned int i = 0; i < matches.size() / 2; ++i) {
		pair<string, int> pair1 = matches[2 * i];
		pair<string, int> pair2 = matches[2 * (i)+1];
		match.push_back(pair2.second);
		if (t1[pair1.second] != t2[pair2.second]) {
			join = false;
			break;
		}
	}
	
	if (join) {
		relationJoin(t1, t2, newRelation, match);
	}
}

vector<int> Interpreter::findLiterals(vector<string>& schemes, map<string, Relation>& relations, vector<pair<string, int>>& matches) {
	Tuple t1;
	Tuple t2;
	vector<int> literals;
	for (int i = 0; i < schemes.size(); ++i) {
		if (schemes[i][0] == '\'') {
			literals.push_back(i);
		}
					
	}
	return literals;
}

void Interpreter::iterateTuples(vector<pair<string, int>>&matches, vector<int>& literals, vector<string>& schemes,Relation& newRelation) {
	map<string, Relation> relations = database.getRelations();	
	for (int i = 0; i < matches.size() / 2; ++i) {
        iterateTuples2(i, relations, matches, literals,schemes,newRelation);
    }
}

void Interpreter::iterateTuples2(int i, map<string,Relation>&relations, vector<pair<string, int>>&matches, vector<int>& literals, vector<string>& schemes,Relation& newRelation) {
    Tuple t1;
    Tuple t2;
    pair<string, int> pair1 = matches[2 * i];
    string value1 = pair1.first;
    Relation r1 = relations.at(value1);
    set<Tuple> tuples1 = r1.getTuples();
    pair<string, int> pair2 = matches[2 * (i)+1];
    string value2 = pair2.first;
    Relation r2 = relations.at(value2);
    set<Tuple> tuples2 = r2.getTuples();
    for (set<Tuple>::iterator it1 = tuples1.begin(); it1 != tuples1.end(); ++it1) {
        t1 = *it1;
        for (set<Tuple>::iterator it2 = tuples2.begin(); it2 != tuples2.end(); ++it2) {
            t2 = *it2;
            if (literals.size() > 0) {
                bool valid = false;
                for (int k = 0; k < t1.size(); k++) {
                    if (t1[k] == schemes[k]) {
                        valid = true;
                    }
                    else if (schemes[k][0] == '\'') {
                        valid = false;
                        break;
                    }
                }
                if (valid) {
                    joinable(matches, t2, t1, newRelation);
                }
            }
            else {
                joinable(matches, t1, t2, newRelation);
            }
        }
    }
}

